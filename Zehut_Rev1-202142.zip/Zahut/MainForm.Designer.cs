﻿
namespace Zahut
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.labelSoftwareTitle = new System.Windows.Forms.Label();
            this.labelSoftwareDescription = new System.Windows.Forms.Label();
            this.panelTop = new System.Windows.Forms.Panel();
            this.panelLeft = new System.Windows.Forms.Panel();
            this.buttonExit = new System.Windows.Forms.Button();
            this.buttonAbout = new System.Windows.Forms.Button();
            this.buttonClearDeviceId = new System.Windows.Forms.Button();
            this.buttonWriteDeviceId = new System.Windows.Forms.Button();
            this.buttonReadDeviceId = new System.Windows.Forms.Button();
            this.buttonFindDevices = new System.Windows.Forms.Button();
            this.panelLogo = new System.Windows.Forms.Panel();
            this.panelMainBody = new System.Windows.Forms.Panel();
            this.comboBoxDeviceId = new System.Windows.Forms.ComboBox();
            this.textBoxMain = new System.Windows.Forms.TextBox();
            this.comboBoxBaudRate = new System.Windows.Forms.ComboBox();
            this.comboBoxComPort = new System.Windows.Forms.ComboBox();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.panelTop.SuspendLayout();
            this.panelLeft.SuspendLayout();
            this.panelMainBody.SuspendLayout();
            this.SuspendLayout();
            // 
            // labelSoftwareTitle
            // 
            this.labelSoftwareTitle.AutoSize = true;
            this.labelSoftwareTitle.Font = new System.Drawing.Font("Century Gothic", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSoftwareTitle.ForeColor = System.Drawing.Color.White;
            this.labelSoftwareTitle.Location = new System.Drawing.Point(33, 59);
            this.labelSoftwareTitle.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.labelSoftwareTitle.Name = "labelSoftwareTitle";
            this.labelSoftwareTitle.Size = new System.Drawing.Size(205, 78);
            this.labelSoftwareTitle.TabIndex = 4;
            this.labelSoftwareTitle.Text = "Zehūt";
            // 
            // labelSoftwareDescription
            // 
            this.labelSoftwareDescription.AutoSize = true;
            this.labelSoftwareDescription.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.labelSoftwareDescription.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.labelSoftwareDescription.Location = new System.Drawing.Point(39, 137);
            this.labelSoftwareDescription.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.labelSoftwareDescription.Name = "labelSoftwareDescription";
            this.labelSoftwareDescription.Size = new System.Drawing.Size(510, 39);
            this.labelSoftwareDescription.TabIndex = 3;
            this.labelSoftwareDescription.Text = "Microcontroller Device ID Utility ";
            this.labelSoftwareDescription.Click += new System.EventHandler(this.labelSoftwareDescription_Click);
            // 
            // panelTop
            // 
            this.panelTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(58)))), ((int)(((byte)(70)))));
            this.panelTop.Controls.Add(this.labelSoftwareTitle);
            this.panelTop.Controls.Add(this.labelSoftwareDescription);
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(360, 0);
            this.panelTop.Margin = new System.Windows.Forms.Padding(4);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(1440, 240);
            this.panelTop.TabIndex = 5;
            this.panelTop.Paint += new System.Windows.Forms.PaintEventHandler(this.panelTop_Paint);
            // 
            // panelLeft
            // 
            this.panelLeft.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(58)))), ((int)(((byte)(70)))));
            this.panelLeft.Controls.Add(this.buttonExit);
            this.panelLeft.Controls.Add(this.buttonAbout);
            this.panelLeft.Controls.Add(this.buttonClearDeviceId);
            this.panelLeft.Controls.Add(this.buttonWriteDeviceId);
            this.panelLeft.Controls.Add(this.buttonReadDeviceId);
            this.panelLeft.Controls.Add(this.buttonFindDevices);
            this.panelLeft.Controls.Add(this.panelLogo);
            this.panelLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelLeft.Location = new System.Drawing.Point(0, 0);
            this.panelLeft.Margin = new System.Windows.Forms.Padding(4);
            this.panelLeft.Name = "panelLeft";
            this.panelLeft.Size = new System.Drawing.Size(360, 1154);
            this.panelLeft.TabIndex = 8;
            // 
            // buttonExit
            // 
            this.buttonExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(58)))), ((int)(((byte)(70)))));
            this.buttonExit.Dock = System.Windows.Forms.DockStyle.Top;
            this.buttonExit.FlatAppearance.BorderSize = 0;
            this.buttonExit.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(78)))), ((int)(((byte)(90)))));
            this.buttonExit.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(78)))), ((int)(((byte)(90)))));
            this.buttonExit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(78)))), ((int)(((byte)(90)))));
            this.buttonExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonExit.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonExit.ForeColor = System.Drawing.Color.White;
            this.buttonExit.Location = new System.Drawing.Point(0, 817);
            this.buttonExit.Margin = new System.Windows.Forms.Padding(6);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(360, 115);
            this.buttonExit.TabIndex = 7;
            this.buttonExit.Text = "Exit";
            this.buttonExit.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonExit.UseVisualStyleBackColor = false;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // buttonAbout
            // 
            this.buttonAbout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(58)))), ((int)(((byte)(70)))));
            this.buttonAbout.Dock = System.Windows.Forms.DockStyle.Top;
            this.buttonAbout.FlatAppearance.BorderSize = 0;
            this.buttonAbout.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(78)))), ((int)(((byte)(90)))));
            this.buttonAbout.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(78)))), ((int)(((byte)(90)))));
            this.buttonAbout.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(78)))), ((int)(((byte)(90)))));
            this.buttonAbout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAbout.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAbout.ForeColor = System.Drawing.Color.White;
            this.buttonAbout.Location = new System.Drawing.Point(0, 702);
            this.buttonAbout.Margin = new System.Windows.Forms.Padding(6);
            this.buttonAbout.Name = "buttonAbout";
            this.buttonAbout.Size = new System.Drawing.Size(360, 115);
            this.buttonAbout.TabIndex = 6;
            this.buttonAbout.Text = "About";
            this.buttonAbout.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonAbout.UseVisualStyleBackColor = false;
            this.buttonAbout.Click += new System.EventHandler(this.buttonAbout_Click);
            // 
            // buttonClearDeviceId
            // 
            this.buttonClearDeviceId.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(58)))), ((int)(((byte)(70)))));
            this.buttonClearDeviceId.Dock = System.Windows.Forms.DockStyle.Top;
            this.buttonClearDeviceId.FlatAppearance.BorderSize = 0;
            this.buttonClearDeviceId.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(78)))), ((int)(((byte)(90)))));
            this.buttonClearDeviceId.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(78)))), ((int)(((byte)(90)))));
            this.buttonClearDeviceId.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(78)))), ((int)(((byte)(90)))));
            this.buttonClearDeviceId.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonClearDeviceId.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonClearDeviceId.ForeColor = System.Drawing.Color.White;
            this.buttonClearDeviceId.Location = new System.Drawing.Point(0, 587);
            this.buttonClearDeviceId.Margin = new System.Windows.Forms.Padding(6);
            this.buttonClearDeviceId.Name = "buttonClearDeviceId";
            this.buttonClearDeviceId.Size = new System.Drawing.Size(360, 115);
            this.buttonClearDeviceId.TabIndex = 5;
            this.buttonClearDeviceId.Text = "Clear Device ID";
            this.buttonClearDeviceId.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonClearDeviceId.UseVisualStyleBackColor = false;
            this.buttonClearDeviceId.Click += new System.EventHandler(this.buttonClearDeviceId_Click);
            // 
            // buttonWriteDeviceId
            // 
            this.buttonWriteDeviceId.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(58)))), ((int)(((byte)(70)))));
            this.buttonWriteDeviceId.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.buttonWriteDeviceId.Dock = System.Windows.Forms.DockStyle.Top;
            this.buttonWriteDeviceId.FlatAppearance.BorderSize = 0;
            this.buttonWriteDeviceId.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(78)))), ((int)(((byte)(90)))));
            this.buttonWriteDeviceId.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(78)))), ((int)(((byte)(90)))));
            this.buttonWriteDeviceId.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(78)))), ((int)(((byte)(90)))));
            this.buttonWriteDeviceId.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonWriteDeviceId.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonWriteDeviceId.ForeColor = System.Drawing.Color.White;
            this.buttonWriteDeviceId.Location = new System.Drawing.Point(0, 472);
            this.buttonWriteDeviceId.Margin = new System.Windows.Forms.Padding(6);
            this.buttonWriteDeviceId.Name = "buttonWriteDeviceId";
            this.buttonWriteDeviceId.Size = new System.Drawing.Size(360, 115);
            this.buttonWriteDeviceId.TabIndex = 4;
            this.buttonWriteDeviceId.Text = "Write Device ID";
            this.buttonWriteDeviceId.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonWriteDeviceId.UseVisualStyleBackColor = false;
            this.buttonWriteDeviceId.Click += new System.EventHandler(this.buttonWriteDeviceId_Click);
            // 
            // buttonReadDeviceId
            // 
            this.buttonReadDeviceId.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(58)))), ((int)(((byte)(70)))));
            this.buttonReadDeviceId.Dock = System.Windows.Forms.DockStyle.Top;
            this.buttonReadDeviceId.FlatAppearance.BorderSize = 0;
            this.buttonReadDeviceId.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(78)))), ((int)(((byte)(90)))));
            this.buttonReadDeviceId.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(78)))), ((int)(((byte)(90)))));
            this.buttonReadDeviceId.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(78)))), ((int)(((byte)(90)))));
            this.buttonReadDeviceId.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonReadDeviceId.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonReadDeviceId.ForeColor = System.Drawing.Color.White;
            this.buttonReadDeviceId.Location = new System.Drawing.Point(0, 357);
            this.buttonReadDeviceId.Margin = new System.Windows.Forms.Padding(6);
            this.buttonReadDeviceId.Name = "buttonReadDeviceId";
            this.buttonReadDeviceId.Size = new System.Drawing.Size(360, 115);
            this.buttonReadDeviceId.TabIndex = 3;
            this.buttonReadDeviceId.Text = "Read Device ID";
            this.buttonReadDeviceId.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonReadDeviceId.UseVisualStyleBackColor = false;
            this.buttonReadDeviceId.Click += new System.EventHandler(this.buttonReadDeviceId_Click);
            // 
            // buttonFindDevices
            // 
            this.buttonFindDevices.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(58)))), ((int)(((byte)(70)))));
            this.buttonFindDevices.Dock = System.Windows.Forms.DockStyle.Top;
            this.buttonFindDevices.FlatAppearance.BorderSize = 0;
            this.buttonFindDevices.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(78)))), ((int)(((byte)(90)))));
            this.buttonFindDevices.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(78)))), ((int)(((byte)(90)))));
            this.buttonFindDevices.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(78)))), ((int)(((byte)(90)))));
            this.buttonFindDevices.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonFindDevices.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonFindDevices.ForeColor = System.Drawing.Color.White;
            this.buttonFindDevices.Location = new System.Drawing.Point(0, 242);
            this.buttonFindDevices.Margin = new System.Windows.Forms.Padding(6);
            this.buttonFindDevices.Name = "buttonFindDevices";
            this.buttonFindDevices.Size = new System.Drawing.Size(360, 115);
            this.buttonFindDevices.TabIndex = 2;
            this.buttonFindDevices.Text = "Find Devices";
            this.buttonFindDevices.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonFindDevices.UseVisualStyleBackColor = false;
            this.buttonFindDevices.Click += new System.EventHandler(this.buttonFindDevices_Click);
            // 
            // panelLogo
            // 
            this.panelLogo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(58)))), ((int)(((byte)(70)))));
            this.panelLogo.BackgroundImage = global::Zahut.Properties.Resources.openSourceLogo;
            this.panelLogo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panelLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelLogo.Location = new System.Drawing.Point(0, 0);
            this.panelLogo.Name = "panelLogo";
            this.panelLogo.Size = new System.Drawing.Size(360, 242);
            this.panelLogo.TabIndex = 9;
            this.panelLogo.Paint += new System.Windows.Forms.PaintEventHandler(this.panelLogo_Paint);
            // 
            // panelMainBody
            // 
            this.panelMainBody.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(68)))), ((int)(((byte)(80)))));
            this.panelMainBody.Controls.Add(this.comboBoxDeviceId);
            this.panelMainBody.Controls.Add(this.textBoxMain);
            this.panelMainBody.Controls.Add(this.comboBoxBaudRate);
            this.panelMainBody.Controls.Add(this.comboBoxComPort);
            this.panelMainBody.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelMainBody.Location = new System.Drawing.Point(360, 240);
            this.panelMainBody.Margin = new System.Windows.Forms.Padding(4);
            this.panelMainBody.Name = "panelMainBody";
            this.panelMainBody.Size = new System.Drawing.Size(1440, 914);
            this.panelMainBody.TabIndex = 5;
            this.panelMainBody.Paint += new System.Windows.Forms.PaintEventHandler(this.panelMainBody_Paint);
            // 
            // comboBoxDeviceId
            // 
            this.comboBoxDeviceId.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(188)))), ((int)(((byte)(200)))));
            this.comboBoxDeviceId.Font = new System.Drawing.Font("Century Gothic", 13.25F);
            this.comboBoxDeviceId.FormattingEnabled = true;
            this.comboBoxDeviceId.Location = new System.Drawing.Point(952, 31);
            this.comboBoxDeviceId.Margin = new System.Windows.Forms.Padding(6);
            this.comboBoxDeviceId.Name = "comboBoxDeviceId";
            this.comboBoxDeviceId.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.comboBoxDeviceId.Size = new System.Drawing.Size(464, 50);
            this.comboBoxDeviceId.TabIndex = 3;
            this.comboBoxDeviceId.Text = "DEVICE ID LIST";
            // 
            // textBoxMain
            // 
            this.textBoxMain.AcceptsReturn = true;
            this.textBoxMain.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxMain.Font = new System.Drawing.Font("Century Gothic", 12.25F);
            this.textBoxMain.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(58)))), ((int)(((byte)(70)))));
            this.textBoxMain.Location = new System.Drawing.Point(18, 115);
            this.textBoxMain.Margin = new System.Windows.Forms.Padding(6);
            this.textBoxMain.Multiline = true;
            this.textBoxMain.Name = "textBoxMain";
            this.textBoxMain.ReadOnly = true;
            this.textBoxMain.Size = new System.Drawing.Size(1398, 771);
            this.textBoxMain.TabIndex = 4;
            this.textBoxMain.TextChanged += new System.EventHandler(this.textBoxMain_TextChanged);
            // 
            // comboBoxBaudRate
            // 
            this.comboBoxBaudRate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(188)))), ((int)(((byte)(200)))));
            this.comboBoxBaudRate.Font = new System.Drawing.Font("Century Gothic", 13.25F);
            this.comboBoxBaudRate.FormattingEnabled = true;
            this.comboBoxBaudRate.Location = new System.Drawing.Point(486, 31);
            this.comboBoxBaudRate.Margin = new System.Windows.Forms.Padding(6);
            this.comboBoxBaudRate.Name = "comboBoxBaudRate";
            this.comboBoxBaudRate.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.comboBoxBaudRate.Size = new System.Drawing.Size(464, 50);
            this.comboBoxBaudRate.TabIndex = 1;
            this.comboBoxBaudRate.Text = "BAUD RATE";
            // 
            // comboBoxComPort
            // 
            this.comboBoxComPort.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(188)))), ((int)(((byte)(200)))));
            this.comboBoxComPort.Font = new System.Drawing.Font("Century Gothic", 13.25F);
            this.comboBoxComPort.FormattingEnabled = true;
            this.comboBoxComPort.Location = new System.Drawing.Point(20, 31);
            this.comboBoxComPort.Margin = new System.Windows.Forms.Padding(6);
            this.comboBoxComPort.Name = "comboBoxComPort";
            this.comboBoxComPort.Size = new System.Drawing.Size(464, 50);
            this.comboBoxComPort.Sorted = true;
            this.comboBoxComPort.TabIndex = 0;
            this.comboBoxComPort.Text = "COM PORT";
            // 
            // serialPort1
            // 
            this.serialPort1.ReadTimeout = 1500;
            this.serialPort1.WriteTimeout = 1500;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1800, 1154);
            this.Controls.Add(this.panelTop);
            this.Controls.Add(this.panelMainBody);
            this.Controls.Add(this.panelLeft);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panelTop.ResumeLayout(false);
            this.panelTop.PerformLayout();
            this.panelLeft.ResumeLayout(false);
            this.panelMainBody.ResumeLayout(false);
            this.panelMainBody.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label labelSoftwareDescription;
        private System.Windows.Forms.Label labelSoftwareTitle;
        private System.Windows.Forms.Panel panelTop;
        private System.Windows.Forms.Panel panelLeft;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Button buttonAbout;
        private System.Windows.Forms.Button buttonClearDeviceId;
        private System.Windows.Forms.Button buttonWriteDeviceId;
        private System.Windows.Forms.Button buttonReadDeviceId;
        private System.Windows.Forms.Button buttonFindDevices;
        private System.Windows.Forms.Panel panelLogo;
        private System.Windows.Forms.Panel panelMainBody;
        private System.Windows.Forms.ComboBox comboBoxDeviceId;
        private System.Windows.Forms.TextBox textBoxMain;
        private System.Windows.Forms.ComboBox comboBoxBaudRate;
        private System.Windows.Forms.ComboBox comboBoxComPort;
        private System.IO.Ports.SerialPort serialPort1;
    }
}

