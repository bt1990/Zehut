﻿using System;
using System.IO.Ports;
using System.Runtime.InteropServices;
using System.Windows.Forms;


namespace Zahut
{
    public partial class MainForm : Form
    {
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn
      (
          int nLeftRect,     // x-coordinate of upper-left corner
          int nTopRect,      // y-coordinate of upper-left corner
          int nRightRect,    // x-coordinate of lower-right corner
          int nBottomRect,   // y-coordinate of lower-right corner
          int nWidthEllipse, // width of ellipse
          int nHeightEllipse // height of ellipse
           );

        public MainForm()
        {
            InitializeComponent();

            //rounded corners setup on MainForm
            FormBorderStyle = FormBorderStyle.None;
            Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, 35, 35));

            //Tool tip for find devices button
            buttonFindDevices.MouseHover += buttonFindDevices_MouseHover;

            //strings of supported baud rates
            string[] baudRates = { "460800", "230400", "115200", "57600", "38400", "19200", "14400", "9600", "4800", "2400", "1200", "600", "300" };

            //populate baud rate combobox with supported baud rates
            foreach (string baud in baudRates)
            {
                comboBoxBaudRate.Items.Add(baud);
            }

            //string[] idList;
            for (int i = 0; i <= 254; i++)
            {
                comboBoxDeviceId.Items.Add(i);
            }

            //display program getting started instructions
            textBoxMain.Text = "Select Find Devices to Discover Connected μController(s)" + Environment.NewLine;
        }

        private void buttonFindDevices_MouseHover(object sender, EventArgs e)
        {
            //tool tip display for find devices button
            System.Windows.Forms.ToolTip ToolTip1 = new System.Windows.Forms.ToolTip();
            ToolTip1.SetToolTip(buttonFindDevices, "Click to discover connected μControllers");
        }

        private void buttonFindDevices_Click(object sender, EventArgs e)
        {
            //get a list of serial port names and initialize bool to track whether serial ports were found
            string[] ports = SerialPort.GetPortNames();
            bool foundPorts = false;

            //populate combo box with found ports, display found ports in text box
            foreach (string port in ports)
            {
                //prevent com port combo box from populating duplicates
                if (!comboBoxComPort.Items.Contains(port))
                {
                    comboBoxComPort.Items.Add(port);
                }

                //show found com ports in main text box, set foundPorts to true
                string displayFoundDevs = "μController(s) Found on:";
                textBoxMain.Text = displayFoundDevs + Environment.NewLine + Environment.NewLine + port + Environment.NewLine;
                textBoxMain.Text += Environment.NewLine + "Select COM Port and Baud Rate to Proceed." + Environment.NewLine;
                foundPorts = true;
            }

            //if no ports were found, show pop up window with error details and how to fix
            if (!foundPorts)
            {
                MessageBox.Show("No μController Detected.\r\nCheck connection and try again.", "Error");
            }
        }

        private void buttonReadDeviceId_Click(object sender, EventArgs e)
        {
            string selectedPort;
            int selectedBaudRate;

            //if no com port or baud rate selected from combo boxes, show pop up window on error details and how to proceed
            if (comboBoxComPort.SelectedItem == null || comboBoxBaudRate.SelectedItem == null)
            {
                MessageBox.Show("One of the following has not been selected\nor was incorrectly selected:\n\nCOM Port\nBaud Rate\n\nPlease Try Again.", "Error");
            }
            //otherwise, take in values from combo boxes
            else
            {
                selectedPort = comboBoxComPort.GetItemText(comboBoxComPort.SelectedItem);
                selectedBaudRate = int.Parse(comboBoxBaudRate.GetItemText(comboBoxBaudRate.SelectedItem));

                try
                {
                    serialPort1.PortName = selectedPort; //port name equals COM port selected by user from combo box
                    serialPort1.BaudRate = selectedBaudRate; //baud rate equals COM port selected by user from combo box
                    serialPort1.Open(); //try to open selected COM port with selected baud rate

                    serialPort1.WriteLine("*GET_ID"); //ping uController for device ID
                    string rxSerString = serialPort1.ReadLine(); //read back uController device ID
                    string displayDevId = "μController Device ID on " + selectedPort + " is currently: ";
                    textBoxMain.Text += Environment.NewLine + displayDevId + rxSerString + Environment.NewLine; //display devID in main text box
                    serialPort1.Close(); //close serial port
                }
                //if baud rate is incorrect (garbage received from serial com) alert user of error and how to proceed
                catch (TimeoutException)
                {
                    MessageBox.Show("Incorrect Baud Rate Detected.\nChoose a New Baud Rate and Try Again.", "Error");
                    serialPort1.Close();
                }
            }
        }

        private void buttonWriteDeviceId_Click(object sender, EventArgs e)
        {
            string selectedPort;
            int selectedBaudRate;
            int newId;
            string currentIdString;

            //if no com port or baud rate or device ID selected from combo boxes, show pop up window on error details and how to proceed
            if (comboBoxComPort.SelectedItem == null || comboBoxBaudRate.SelectedItem == null || comboBoxDeviceId.SelectedItem == null)
            {
                MessageBox.Show("One of the following has not been selected\nor was incorrectly selected:\n\nCOM Port\nBaud Rate\nDevice ID\n\nPlease Try Again.", "Error");
            }
            //otherwise proceed
            else
            {
                selectedPort = comboBoxComPort.GetItemText(comboBoxComPort.SelectedItem);
                selectedBaudRate = int.Parse(comboBoxBaudRate.GetItemText(comboBoxBaudRate.SelectedItem));
                serialPort1.PortName = selectedPort;
                newId = int.Parse(comboBoxDeviceId.GetItemText(comboBoxDeviceId.SelectedItem));
                try
                {
                    serialPort1.PortName = selectedPort; //port name equals COM port selected by user from combo box
                    serialPort1.BaudRate = selectedBaudRate; //baud rate equals COM port selected by user from combo box
                    serialPort1.Open(); //try to open selected COM port with selected baud rate
                    serialPort1.WriteLine("*GET_ID"); //ping uController for device ID
                    currentIdString = serialPort1.ReadLine();  //read back uController device ID
                    int currentIdInt = int.Parse(currentIdString); //convert to int

                    //if current device ID equals the new device ID selected by user, throw error and how to proceed
                    if (currentIdInt == newId)
                    {
                        MessageBox.Show("New device ID is the same as the current device ID\n\nPlease choose a different device ID and try again.", "Error");
                        serialPort1.Close();
                    }
                    else
                    {
                        //otherwise write the new ID, read it back, and confirm to user the new ID was set
                        serialPort1.WriteLine("*SET_ID" + newId);
                        serialPort1.WriteLine("*GET_ID");

                        string rxSerString;
                        string updatedDevId = "μController Device ID on " + selectedPort + " has been changed to: ";
                        rxSerString = serialPort1.ReadLine();
                        textBoxMain.Text += Environment.NewLine + updatedDevId + rxSerString + Environment.NewLine;
                        serialPort1.Close();
                    }
                }

                //if baud rate is incorrect (garbage received from serial com) alert user of error and how to proceed
                catch (TimeoutException)
                {
                    MessageBox.Show("Incorrect Baud Rate Detected.\nChoose a New Baud Rate and Try Again.", "Error");
                    serialPort1.Close();
                }
            }
        }

        private void buttonClearDeviceId_Click(object sender, EventArgs e)
        {
            string selectedPort;
            int selectedBaudRate;

            if (comboBoxComPort.SelectedItem == null || comboBoxBaudRate.SelectedItem == null)
            {
                MessageBox.Show("One of the following has not been selected\nor was incorrectly selected:\n\nCOM Port\nBaud Rate\n\nPlease Try Again.", "Error");
            }
            else
            {
                selectedPort = comboBoxComPort.GetItemText(comboBoxComPort.SelectedItem);
                selectedBaudRate = int.Parse(comboBoxBaudRate.GetItemText(comboBoxBaudRate.SelectedItem));
                serialPort1.PortName = selectedPort;
                try
                {
                    serialPort1.PortName = selectedPort; //port name equals COM port selected by user from combo box
                    serialPort1.BaudRate = selectedBaudRate; //baud rate equals COM port selected by user from combo box
                    serialPort1.Open(); //try to open selected COM port with selected baud rate
                    serialPort1.WriteLine("*SET_ID255"); //clear device ID (setting to 255 on arduino is a clear EEPROM byte)
                    string clearedDevId = ("μController Device ID has been cleared."); //confirm to user device ID cleared
                    textBoxMain.Text += (Environment.NewLine + clearedDevId + Environment.NewLine);
                    serialPort1.Close();
                }
                //if baud rate is incorrect (garbage received from serial com) alert user of error and how to proceed
                catch (TimeoutException)
                {
                    MessageBox.Show("Incorrect Baud Rate Detected.\nChoose a New Baud Rate and Try Again.", "Error");
                    serialPort1.Close();
                }
            }
        }

        private void buttonAbout_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Zehut: Microprocessor Device ID Utility\n\nRev1 (2021-42)\nDeveloped by: BT1990\n\nSource Code Available on GitHub under the Open Source License Agrement:\n\nhttps://github.com/bt1990/Zehut.git\nhttps://opensource.org/ToS", "About");
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }

        private void textBoxMain_TextChanged(object sender, EventArgs e)
        {
            if (textBoxMain.Visible)
            {
                textBoxMain.SelectionStart = textBoxMain.TextLength;
                textBoxMain.ScrollToCaret();
            }
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panelMainBody_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panelLogo_Paint(object sender, PaintEventArgs e)
        {

        }

        private void comboBoxDeviceId_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void labelSoftwareDescription_Click(object sender, EventArgs e)
        {

        }

        private void panelTop_Paint(object sender, PaintEventArgs e)
        {

        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void comboBoxComPort_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void splitContainer1_Panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void comboBoxComPort_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void comboBoxBaudRate_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void labelExit_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }
    }
}
